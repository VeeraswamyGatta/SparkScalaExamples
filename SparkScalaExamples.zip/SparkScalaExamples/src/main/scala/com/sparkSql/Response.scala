package com.sparkSql

case class Response(country: String, age_midpoint: Option[Double], occupation: String, salary_midpoint: Option[Double])
