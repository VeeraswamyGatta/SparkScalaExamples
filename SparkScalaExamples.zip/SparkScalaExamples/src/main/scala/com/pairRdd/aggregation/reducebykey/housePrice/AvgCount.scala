package com.pairRdd.aggregation.reducebykey.housePrice

case class AvgCount(count: Int, total: Double)

